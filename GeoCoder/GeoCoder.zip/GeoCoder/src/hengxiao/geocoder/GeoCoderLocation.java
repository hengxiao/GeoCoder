package hengxiao.geocoder;

public class GeoCoderLocation {
	public double latitude;
	public double longtitude;
	public boolean partial_match;
	public GeoCoderLocationType[] types;
}

package hengxiao.geocoder;

public enum GeoCoderLocationType {
	ROOFTOP,
	RANGE_INTERPOLATED,
	GEOMETRIC_CENTER,
	APPROXIMATE
}

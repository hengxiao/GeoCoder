package main;

public enum GeoCoderLocationType {
	ROOFTOP,
	RANGE_INTERPOLATED,
	GEOMETRIC_CENTER,
	APPROXIMATE
}
